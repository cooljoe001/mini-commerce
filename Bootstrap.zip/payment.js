const paymentForm = document.getElementById('paymentForm');
const mail = document.querySelector("input[type='email']");
const phone = document.querySelector("input[type='tel']");
console.log(mail,phone);
const $totalAmt = window.document.querySelector(".total span");

let  items = window.localStorage.getItem("cartItems");
items = JSON.parse(items);
const amt = items.map((v)=> v.price).reduce((v,i)=>v+i).toFixed(2);
$totalAmt.innerHTML =amt;


console.log(paymentForm);
paymentForm.addEventListener("submit", payWithPaystack, false);

function payWithPaystack(e) {
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: 'pk_test_7044ec8d930de237feb60216463a8bd3dfc5a12d', // Replace with your public key
    email: mail.value,
    amount:  amt* 100,
    currency: "GHS",
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  });

  handler.openIframe();
}
